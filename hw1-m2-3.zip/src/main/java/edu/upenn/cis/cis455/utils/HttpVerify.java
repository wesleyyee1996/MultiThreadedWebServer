package edu.upenn.cis.cis455.utils;

import edu.upenn.cis.cis455.m1.interfaces.Response;
import edu.upenn.cis.cis455.m2.interfaces.Request;

public class HttpVerify {
	

	public int verify(Request request, Response response) {
		
		return 200;
	}
}
