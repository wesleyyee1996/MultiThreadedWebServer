//package edu.upenn.cis.cis455.utils;
//
//import edu.upenn.cis.cis455.m2.interfaces.Session;
//
///**
// * Handles use cases from RFC 6265 around the session
// * @author vagrant
// *
// */
//public class SessionHandler {
//	
//	Session _session;
//	
//	/**
//	 * Instantiate by passing in the Session that you want to manipulate
//	 * @param session
//	 */
//	public SessionHandler(Session session) {
//		this._session = session;
//	}
//	
//	public String setCookie(String key, String value) {
//		
//	}
//	
//	
//	
//	// creates a string version of a cookie in format "key: value"
//	public String createCookie(String key, String value) {
//		return key + ": " + value;
//	}
//	
//}
