package edu.upenn.cis.cis455;

public enum StatusCodeMessage {
	
	
}
