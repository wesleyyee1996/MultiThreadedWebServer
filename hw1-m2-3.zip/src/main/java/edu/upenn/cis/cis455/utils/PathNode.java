package edu.upenn.cis.cis455.utils;

public class PathNode<T> {
	public String value;
	public PathNode<T> next;
	public PathNode<T> prev;
	public PathNode<T> head;
	
	public PathNode() {};
	
//	public PathNode(PathNode<T> head, PathNode<T> prev) {
//		this.head = head;
//		this.prev = prev;
//	}
}
