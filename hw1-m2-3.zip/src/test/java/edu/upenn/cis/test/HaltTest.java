package edu.upenn.cis.test;

/** 
 * Tests that the Halt Exception is working correctly
 * @author vagrant
 *
 */
public class HaltTest {

}
